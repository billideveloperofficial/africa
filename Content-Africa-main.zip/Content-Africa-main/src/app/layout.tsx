
"use client";

import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { usePathname } from "next/navigation";
import { AuthProvider } from "@/hooks/use-auth";


// This is a temporary fix for the metadata.
// In a real app, you'd want to handle this more dynamically.
// export const metadata: Metadata = {
//   title: "Avibe UGC - Influencers & User Generated Content Creators",
//   description:
//     "Put your brand where your audience is - hire influencers, creators, streamers, and podcasters. Access brand deals and sponsorships as a creator.",
// };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const pathname = usePathname();
  const isAdminPage = pathname.startsWith('/admin');
  const isSignUpPage = pathname === '/become-a-creator' || pathname === '/signup';

  return (
    <html lang="en" className="scroll-smooth" suppressHydrationWarning>
      <head>
        <title>Avibe UGC - Influencers & User Generated Content Creators</title>
        <meta name="description" content="Put your brand where your audience is - hire influencers, creators, streamers, and podcasters. Access brand deals and sponsorships as a creator." />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-body bg-background text-foreground antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            {!isSignUpPage && !isAdminPage && <Header />}
            <main>{children}</main>
            {!isSignUpPage && !isAdminPage && <Footer />}
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
