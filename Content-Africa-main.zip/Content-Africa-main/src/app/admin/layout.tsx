
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { Header } from "@/components/layout/header";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <Header />
      <div className="container grid lg:grid-cols-5 gap-12 py-8">
        <aside className="hidden lg:block lg:col-span-1">
          <AdminSidebar />
        </aside>
        <main className="lg:col-span-4">{children}</main>
      </div>
    </>
  );
}
