"use client";

import * as React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Card,
  CardContent,
  CardHeader,
} from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Star, TrendingUp } from "lucide-react";
import Autoplay from "embla-carousel-autoplay";

const testimonials = [
  {
    name: "Jessica Wang",
    handle: "@jessicreates",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1887&auto=format&fit=crop",
    aiHint: "woman portrait",
    testimonial:
      "Avibe UGC's AI pitch generator is a game-changer! I've landed three major brand deals in the last month alone. I couldn't have done it without this platform.",
  },
  {
    name: "Mike P.",
    handle: "@techbymike",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1887&auto=format&fit=crop",
    aiHint: "man portrait",
    testimonial:
      "As a smaller creator, I struggled to get noticed by brands. Avibe UGC leveled the playing field and connected me with opportunities I never thought possible.",
  },
  {
    name: "Chloe Chen",
    handle: "@chloetravels",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1961&auto=format&fit=crop",
    aiHint: "woman travel",
    testimonial:
      "The community and resources are invaluable. It's more than just a tool; it's a partner in my creator journey. Highly recommend to any UGC creator.",
  },
  {
    name: "David Lee",
    handle: "@davidleegaming",
    avatar: "https://images.unsplash.com/photo-1557862921-37829c790f19?q=80&w=2071&auto=format&fit=crop",
    aiHint: "gamer man",
    testimonial:
      "The platform made it so easy to find sponsors that align with my gaming channel. The process was seamless and professional.",
  },
  {
    name: "Sophia Rodriguez",
    handle: "@sophiasays",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1888&auto=format&fit=crop",
    aiHint: "woman podcasting",
    testimonial:
      "I love how I can manage all my brand partnerships in one place. It's saved me so much time and effort!",
  },
];

export function SocialProofSection() {
    const plugin = React.useRef(
        Autoplay({ delay: 4000, stopOnInteraction: true, stopOnHover: true })
    );

  return (
    <section className="py-20 md:py-28">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            Trusted by Creators Worldwide
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Don't just take our word for it. Here's what our community is saying.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="flex flex-col justify-center items-center text-center p-8 bg-primary text-primary-foreground">
                <TrendingUp className="h-12 w-12 mb-4" />
                <h3 className="text-4xl font-bold mb-2">$2,500+</h3>
                <p className="text-lg text-primary-foreground/80">Average monthly earnings for creators on Avibe UGC.</p>
            </Card>

            <div className="lg:col-span-2">
                <Carousel
                    opts={{
                    align: "start",
                    loop: true,
                    }}
                    plugins={[plugin.current]}
                    className="w-full"
                >
                    <CarouselContent>
                    {testimonials.map((item, index) => (
                        <CarouselItem key={index} className="md:basis-1/2">
                        <div className="p-1 h-full">
                            <Card className="h-full flex flex-col">
                            <CardHeader>
                                <div className="flex items-center gap-4">
                                <Avatar>
                                    <AvatarImage src={item.avatar} alt={item.name} data-ai-hint={item.aiHint} />
                                    <AvatarFallback>{item.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-semibold">{item.name}</p>
                                    <p className="text-sm text-muted-foreground">{item.handle}</p>
                                </div>
                                </div>
                            </CardHeader>
                            <CardContent className="flex-grow">
                                <p className="text-muted-foreground italic">"{item.testimonial}"</p>
                            </CardContent>
                            <div className="p-6 pt-0 flex text-yellow-400">
                                <Star className="h-5 w-5 fill-current" />
                                <Star className="h-5 w-5 fill-current" />
                                <Star className="h-5 w-5 fill-current" />
                                <Star className="h-5 w-5 fill-current" />
                                <Star className="h-5 w-5 fill-current" />
                            </div>
                            </Card>
                        </div>
                        </CarouselItem>
                    ))}
                    </CarouselContent>
                    <CarouselPrevious className="hidden md:flex" />
                    <CarouselNext className="hidden md:flex"/>
                </Carousel>
            </div>
        </div>
      </div>
    </section>
  );
}
