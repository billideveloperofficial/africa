import { Button } from "@/components/ui/button";
import { MoveRight } from "lucide-react";
import Link from "next/link";

export function CtaSection() {
  return (
    <section className="bg-card">
      <div className="container py-20 md:py-28">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Ready to Elevate Your UGC Career?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Join Avibe UGC today and start landing the brand deals you deserve.
            It's free to get started and unlock your full potential.
          </p>
          <div className="mt-8">
            <Link href="/become-a-creator">
              <Button size="lg">
                Join the Community Today <MoveRight className="ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
