import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Megaphone, ShieldCheck, Sparkles } from "lucide-react";

const features = [
  {
    icon: <Sparkles className="h-8 w-8 text-primary" />,
    title: "AI-Powered Pitches",
    description:
      "Craft compelling, personalized brand pitches in seconds. Our AI analyzes your profile to highlight your unique strengths.",
  },
  {
    icon: <Megaphone className="h-8 w-8 text-primary" />,
    title: "Curated Brand Deals",
    description:
      "No more endless searching. Get matched with brand deals that fit your niche and audience, delivered right to your inbox.",
  },
  {
    icon: <ShieldCheck className="h-8 w-8 text-primary" />,
    title: "Community & Support",
    description:
      "Join a thriving community of fellow creators. Share tips, collaborate, and grow together with our exclusive resources.",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20 md:py-28" id="features">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            Everything You Need to Succeed
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Our platform is packed with powerful features to help you monetize your content and grow your brand.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <Card key={feature.title} className="bg-card hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-primary/10 rounded-full">
                    {feature.icon}
                </div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-muted-foreground">
                <p>{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
