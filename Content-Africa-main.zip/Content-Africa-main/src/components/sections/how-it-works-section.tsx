"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";

const brandSteps = [
  {
    id: "1",
    title: "Find Creator",
    description: "Filter through list of available creators and find creator that suits your need.",
  },
  {
    id: "2",
    title: "Make Payment",
    description: "Make payment & lock funds. Payment will be released to creators on completion.",
  },
  {
    id: "3",
    title: "Mark Complete",
    description: "Receive content from creator, mark complete and release payments accordingly.",
  },
];

const creatorSteps = [
    {
      id: "1",
      title: "Create Your Profile",
      description: "Sign up and create a standout portfolio to showcase your skills and past work to brands.",
    },
    {
      id: "2",
      title: "Get Matched",
      description: "Receive invitations from brands that match your niche and audience.",
    },
    {
      id: "3",
      title: "Get Paid",
      description: "Collaborate with brands, deliver great content, and get paid securely upon completion.",
    },
  ];

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="bg-background py-10 md:py-14">
      <div className="container">
        <div className="bg-card p-8 md:p-12 rounded-2xl shadow-lg">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                    <h2 className="text-3xl md:text-4xl font-bold tracking-tight">How It Works</h2>
                    <p className="text-lg text-muted-foreground">
                        Brands get engaging videos that convert and boost trusts from
                        authentic UGC creators & influencers.
                    </p>
                    <div className="relative aspect-video rounded-xl overflow-hidden">
                        <Image
                            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop"
                            alt="Content creator"
                            layout="fill"
                            objectFit="cover"
                            className="transition-transform duration-300 hover:scale-105"
                            data-ai-hint="woman content creator"
                        />
                    </div>
                </div>
                <div className="space-y-6">
                <Tabs defaultValue="brands" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 bg-transparent p-0">
                        <TabsTrigger value="brands" className="text-lg data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none data-[state=active]:bg-transparent">For Brands</TabsTrigger>
                        <TabsTrigger value="creators" className="text-lg data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none data-[state=active]:bg-transparent">For Creators</TabsTrigger>
                    </TabsList>
                    <TabsContent value="brands">
                        <div className="space-y-4 pt-4">
                            {brandSteps.map((step) => (
                                <Card key={step.id} className="bg-background/50">
                                    <CardContent className="flex items-center gap-6 p-6">
                                        <div className="flex-shrink-0 bg-primary/20 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">
                                            {step.id}
                                        </div>
                                        <div>
                                            <h3 className="font-semibold text-lg">{step.title}</h3>
                                            <p className="text-muted-foreground">{step.description}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                    <TabsContent value="creators">
                    <div className="space-y-4 pt-4">
                            {creatorSteps.map((step) => (
                                <Card key={step.id} className="bg-background/50">
                                    <CardContent className="flex items-center gap-6 p-6">
                                        <div className="flex-shrink-0 bg-primary/20 text-primary h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg">
                                            {step.id}
                                        </div>
                                        <div>
                                            <h3 className="font-semibold text-lg">{step.title}</h3>
                                            <p className="text-muted-foreground">{step.description}</p>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>
                </Tabs>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
}
