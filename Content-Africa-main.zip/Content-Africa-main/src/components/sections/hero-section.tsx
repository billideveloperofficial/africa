"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const creators = [
  { name: 'Podcasters', image: '/49439.jpg', hint: 'man podcasting' },
  { name: 'YouTubers', image: '/26745.jpg', hint: 'man youtube content' },
  { name: 'UGC Creators', image: '/7918.jpg', hint: 'woman content creator' },
  { name: 'Streamers', image: '/12709.jpg', hint: 'woman streaming' },
  { name: 'Bloggers', image: '/2151914220.jpg', hint: 'woman blogging' },
  { name: 'Influencers', image: '/2149194126.jpg', hint: 'woman influencer' },
  { name: 'TikTok Creators', image: '/2149416508.jpg', hint: 'woman tiktok' },
 { name: 'Photographers', image: '/2151609206.jpg', hint: 'photographer taking picture' },
  { name: 'Musicians', image: '/2148847041.jpg', hint: 'musician playing guitar' },
];

export function HeroSection() {
  return (
    <section className="relative bg-background overflow-hidden">
      <div className="container pt-24 pb-12 text-center">
        <Badge
          variant="outline"
          className="mb-4 py-1.5 px-4 text-sm bg-yellow-400/10 border-yellow-400/30 text-yellow-300"
        >
          UGC & Brand Deals
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tighter mb-4">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-[length:400%_auto] animate-gradient">
            Influencers & User Generated
          </span>
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-[length:400%_auto] animate-gradient">
            Content Creators
          </span>
        </h1>
        <p className="text-lg md:text-xl max-w-2xl mx-auto text-muted-foreground mb-8">
          Put your brand where your audience is - hire influencers, creators,
          streamers, and podcasters. Access brand deals and sponsorships as a
          creator.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/hire-creators">
            <Button size="lg" className="bg-indigo-500 hover:bg-indigo-600">Hire Creators</Button>
          </Link>
          <Link href="/become-a-creator" passHref>
            <Button size="lg" variant="outline">Become a Creator</Button>
          </Link>
        </div>
      </div>
      <div className="pb-16">
        <Swiper
          modules={[Autoplay, Pagination]}
          loop={true}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          }}
          slidesPerView={1.5}
          spaceBetween={24}
          centeredSlides={true}
          pagination={{ clickable: true }}
          breakpoints={{
            640: {
              slidesPerView: 2.5,
            },
            1024: {
              slidesPerView: 4.5,
            },
            1280: {
                slidesPerView: 5.5,
            },
          }}
          className="!pb-12"
        >
          {creators.map((creator) => (
            <SwiperSlide key={creator.name}>
              <div className="relative group rounded-xl overflow-hidden aspect-[4/5] md:aspect-[3/4]">
                <img
                  src={creator.image}
                  data-ai-hint={creator.hint}
                  alt={creator.name}
                  width={400}
                  height={500}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <h3 className="text-white text-3xl font-bold">
                    {creator.name}
                  </h3>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
